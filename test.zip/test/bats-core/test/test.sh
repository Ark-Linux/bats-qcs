#!/bin/bash
echo `bats kim.bats > log_kim`
echo `cat log_kim`
bash ./monstor.sh