#!/bin/bash

VAR1="Linuxidc.com"
VAR2="Linuxidc.com"

if [ "$VAR1" = "$VAR2" ]; then
    echo "字符串是相等的。"
else
    echo "字符串是不相等的。"
fi
