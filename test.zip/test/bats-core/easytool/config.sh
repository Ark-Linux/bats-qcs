
#! /bin/bash

ifo=`adb devices`
result=$(echo $ifo | grep -w "device")
title=${result:25:7}
#echo "Device : ${result:25:7}"


if [[ "$result" != "" ]]
then
	clear
  	echo "devices exist"
  	while :
	do
  		echo "******************************"
  		echo "*     Device : $title       *"
  		echo "*            Menu            *"
  		echo "*      1. Set LED Pattern    *"
 	 	echo "*      2. Monitor            *"
  		echo "*      3. View DB File       *"
 	 	echo "*      4. Configure Gpio     *"
 	 	echo "*      5. Wifi Connect       *"
  		echo "*      6. Reboot             *"
  		echo "*      7. Quit               *"
  		echo "******************************"
  		read -p "Enter Number:" mnum
  
  		case $mnum in
  		1)		
		adb pull /data/adk.led.db .
		sqlite3 adk.led.db ".dump" > ~/sql/led.sql
		rm ~/adk.led.db
		clear
  		while :
  		do
  			echo "******************************"
			echo "*         Set LED            *"
  			echo "*  1. Set Normal Pattern     *"
  			echo "*  2. Set Indicate Pattern   *"
  			echo "*  3. Set Reverse Pattern    *"
  			echo "*  4. Back                   *"
  			echo "******************************"
  			read -p "Enter Number:" pset 
			
			mapnum=`grep -rn "INSERT INTO \"config_table\" VALUES('ui.led.pattern.*.type" ~/sql/led.sql | wc -l`
			#echo $mapnum
			for ((i=0; i<$mapnum; i++))
			do
				#echo $i
				info=`grep -rn "INSERT INTO \"config_table\" VALUES('ui.led.pattern.$i.type" ~/sql/led.sql`
				if [ $i -lt 10 ]
				then
					info1=${info:63}
					substr=${info1%%\'*}
					array[$i]="$substr"
					#echo ${array[$i]}
				else
					info1=${info:64}
					substr=${info1%%\'*}
					array[$i]="$substr"
					#echo ${array[$i]}
				fi  
			done

			
 
    			case $pset in
    			1)
			while :
			do
				clear
				for ((i=0; i<$mapnum; i++))
				do
					if [ "${array[$i]}" = "trail" ] || [ "${array[$i]}" = "pulse" ] || [ "${array[$i]}" = "basic" ]
					then
						echo "Enter Pattren Number $i to Set * ${array[$i]} * Pattern"
					fi  
				done
				read -p "Enter Pattern Number:" npnum
				case $npnum in
				[0-99]) 
				npstr="adk-message-send 'led_start_pattern{pattern:}'"
				npstro=${npstr:0:44}$npnum${npstr:44}
				gnome-terminal -x adb shell "$npstro"
				;;

				*)break;;	
				esac
			done
    			;;
    			2)clear
			for ((i=0; i<$mapnum; i++))
			do
				if [ "${array[$i]}" = "direction" ]
				then
					echo "Enter Pattren Number $i to Set * ${array[$i]} * Pattern"
				fi  
			done
    			read -p "Enter Pattern Number:" ipnum
    			ipstr="adk-message-send 'led_indicate_direction_pattern{pattern: direction:0}'"
    			ipstro=${ipstr:0:57}$ipnum${ipstr:57}
    			gnome-terminal -x adb shell "$ipstro"
    			;;
    			3)clear
			for ((i=0; i<$mapnum; i++))
			do
				if [ "${array[$i]}" = "reverse" ]
				then
					echo "Enter Pattren Number $i to Set * ${array[$i]} * Pattern"
				fi  
			done
    			read -p "Enter Pattern Number:" rpnum
    			rpstr="adk-message-send 'led_reverse_direction_pattern{pattern: direction:0}'"
    			rpstro=${rpstr:0:56}$rpnum${rpstr:56}
    			gnome-terminal -x adb shell "$rpstro"
    			;;
		    	4)break
			;;
		    	*)clear
		    	echo "Error Quited"
		    	esac
  		done
		rm ~/sql/led.sql 
  		;;

		2)clear
		echo "******************************"
		echo "*          Monitor           *"
		echo "*      1. Adk Monitor        *"
		echo "*      2. HD Button Event    *"
		echo "*      3. Back               *"
		echo "******************************"
		while :
		do
			read -p "Enter Number:" mset
			case $mset in
			1)gnome-terminal -x adb shell "adk-message-monitor -a"
			;;

			2)
			hinfo=`adb shell ls -l /dev/input | grep "event" | wc -l`
			hinfo=$[hinfo-1]
			echo "TIPS:Event Num:(0~$hinfo)" 
			read -p "Enter Event Num:" enum
			# echo "hd /dev/input/event$enum"
			gnome-terminal -x adb shell "hd /dev/input/event$enum";;

			3)break;;
			*)exit 0;;
			esac
		done
		;;

		3)clear
		echo "******************************"
		echo "*           View             *"
		echo "*      1. Led DB File        *"
		echo "*      2. Button DB File     *"
		echo "*      3. Rules DB File      *"
		echo "*      4. Back               *"
		echo "******************************"
		while : 
		do
			read -p "Enter Number:" vset
			case $vset in
			1)
			adb pull /data/adk.led.db .
			sqlite3 adk.led.db ".dump" > ~/sql/led.sql
			gnome-terminal -x bash -c "cat ~/sql/led.sql; exec bash;"
			rm adk.led.db
			;;
			2)
			adb pull /data/adk.button.db .
			sqlite3 adk.button.db ".dump" > ~/sql/button.sql
			gnome-terminal -x bash -c "cat ~/sql/button.sql; exec bash;"
			rm adk.button.db
			;;
			3)
			adb pull /data/adk.rules.db .
			sqlite3 adk.rules.db ".dump" > ~/sql/rules.sql
			gnome-terminal -x bash -c "cat ~/sql/rules.sql; exec bash;"
			rm adk.rules.db
			;;
			4)
			break
			;;
			*)
			echo "Error Re-Type"
			;;
			esac
		done
		;;

		4)clear
		read -p "Enter GPIO_Num:" gpionum
		read -p "Enter GPIO_Behaviour:" gpiobe
		read -p "Enter GPIO_Value:" gpiov
		str1="echo   > /sys/class/gpio/export"
		str1o=${str1:0:5}$gpionum${str1:5}
		echo $str1o
		str2="echo   > /sys/class/gpio/gpio/direction"
		str2o=${str2:0:5}$gpiobe${str2:5:24}$gpionum${str2:29}
		echo $str2o
		str3="echo   > /sys/class/gpio/gpio/value"
		str3o=${str3:0:5}$gpiov${str3:5:24}$gpionum${str3:29}
		echo $str3o
		str4="echo   > /sys/class/gpio/unexport"
		str4o=${str4:0:5}$gpionum${str4:5}
		echo $str4o
		gnome-terminal -x adb shell "$str1o"
		gnome-terminal -x adb shell "$str2o"
		gnome-terminal -x adb shell "$str3o"
		gnome-terminal -x adb shell "$str4o"
		read pause
		;;

		5)clear
		while :
		do 
			echo "******************************"
			echo "*        Wifi Connect        *"
			echo "*  1. Connect Wifi Directly  *"
			echo "*  2. Modify  Wifi Info      *"
			echo "*  3. Scan Wifi List         *"
			echo "*  4. Back                   *"
			echo "******************************"
			read -p "Enter Number:" wset
			case $wset in
			1)clear
			read -p "Enter ssid:" wssid
			read -p "Enter Password:" wpass
			wstr="adk-message-send 'connectivity_wifi_connect {ssid:\"$wssid\"password:\"$wpass\" homeap:true}'"
			gnome-terminal -x adb shell "adk-message-send 'connectivity_wifi_disable{}'"
			gnome-terminal -x adb shell "adk-message-send 'connectivity_wifi_enable{}'"
			gnome-terminal -x adb shell "adk-message-send 'connectivity_wifi_scan{}'"
			gnome-terminal -x adb shell "$wstr"
			;;
			2)clear
			read -p "Enter ssid:" wwssid
			read -p "Enter Password:" wwpass
			gnome-terminal -x adb shell "adk-message-send 'connectivity_wifi_onboard{}'"
			wwstr="adk-message-send 'connectivity_wifi_connect {ssid:\"$wwssid\"password:\"$wwpass\" homeap:true}'"
			gnome-terminal -x adb shell "$wwstr"
			;;
			3)clear
			gnome-terminal -x adb shell "adk-message-monitor -a"
			gnome-terminal -x adb shell "adk-message-send 'connectivity_wifi_scan{}'"	
			;;
			4)break
			;;
			*);;
			esac
		done
		;;

		6)
		adb reboot
		exit 0;;

		7)clear
		exit 0;;

		lll)
		echo "-*-*-*-Developer Mode-*-*-*-"
		read -p "Input Password:" pw
		if [ "$pw" = "123" ]
		then
			read -p "Enter Mode: 1:Pull 2:Push" selc
			case $selc in
			1)
			rm ~/db/*
			adb pull /data/adk.led.db ~/db
			adb pull /data/adk.button.db ~/db
			adb pull /data/adk.rules.db ~/db
			;;
			2) 
			adb push ~/db/adk.led.db /data 
			adb push ~/db/adk.button.db /data 
			adb push ~/db/adk.rules.db /data 
			;;
			*);;
			esac
		else
			echo "Wrong"
		fi
		;;

		*)clear
		echo "***Error Re-type***";;
		esac
		clear
	done
else
	echo "devices not exist, re-plug or reboot please"
fi
